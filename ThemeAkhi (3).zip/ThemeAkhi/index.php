<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh</title>
  <link rel="stylesheet" href="style.css">
    <?php wp_head();  ?>
</head>
<body>
    <!-- header part start -->
    <header class="cont">
        <div class="row topbar">
            <div class="col-lg-6 header_left">
                <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
            </div>
            <div class="col-lg-6 header_right text-end">
                <p>২১ কার্তিক, ১৪২৯</p>
                <a href="#">English</a>
            </div>
        </div>
    </header>
    <!-- header part end -->
    <!-- logo part start -->
    <section>
      <section class="cont">
        <div class="row logo">
          <div class="col-lg-5 logo_left">
          <div class="class logo">
        <a href="#">
         <?php the_custom_logo();?>

            <img src="/assests/images/header/logo_bn.png" alt="">
        </a>
    </div>
       </div>
<div class="col-lg-5 logo_search">
    <from action="">
       <input type="text"placeholder="খুঁজুন"> 
       <button>অনুসন্ধান</button>
     
    </from>
</div>
<div class="col-lg-2 logo_right d-flex justify-contant-end">
    <div class="logo1">
        <a href="#">
            <img src="/assests/images/header/a2i-logo-footer.png" alt="">
        </a>
    </div>
    <div class="logo2">
        <h6><b>সাথে থাকুন:</b></h6>
        <a href="#"> <img src="/assests/images/header/facebook-icon.png" alt="">
        <img src="/assests/images/header/twitter-blue-icon.png" alt="">
        <img src="/assests/images/header/youtube-icon.png" alt="">
       <img src="/assests/images/header/gplus-icon.png" alt="">
     </a>
    </div>
</div>
    </div>
</section>
    <!-- logo part end -->

    <!-- menu part start -->
    <section class="cont">
    <div class="row ">
        <nav class="navbar navbar-expand-lg bg-light">
            <div class="container-fluid">
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
               <?php wp_nav_menu(array(
                'menu_location'=>'Top_menu',
                'menu_class'=>'navbar-nav main_menu'
               )); ?>

                <!-- <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">হোম</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">বাংলাদেশ সম্পর্কিত</a>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">ই-সেবাসমূহ</a>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">সেবাখাত</a>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">ব্যবসা-বাণিজ্য</a>
                 
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#"> বৈদেশিক বিনিয়োগ</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">আইন-বিধি</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">তথ্য বাতায়ন</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">সেবাকুঞ্জ</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">ফরমস</a>
                  </li>
                </ul> -->
              </div>
            </div>
          </nav>
    </div>
</section>
    <!-- menu part end -->
    <!-- hero part start here -->
    <section class="cont">
      <div class="row hero">
        <div class="col-lg-8 hero_main">
          <div class="banner">
            <a href="#">
              <?php dynamic_sidebar('banner'); ?>
               <img src="/assests/images/sidebar/padmabanner.jpg" class="d-block w-100" alt=""></a>
          </div>
          <!-- slider part start here -->
          <div class="slider">
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="/assests/images/slider/333_gov.png" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="/assests/images/slider/4-02.jpg" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="/assests/images/slider/6.jpg" class="d-block w-100" alt="">
                </div>
                <div class="carousel-item">
                  <img src="/assests/images/slider/corona_banner.jpg" class="d-block w-100" alt="">
                </div>
              </div>
              
            </div>
          </div>
          <!-- slider part end here -->
          <!-- tab part start here -->
          
          <div class="tab">
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">দপ্তর ভিত্তিক সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">সকল ই-সেবা</button>
              </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                <div class="row">
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="/assests/images/tab/agriculture.png" alt="">
                      <p>কৃষি </p>
                    </a>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="/assests/images/tab/call_center.png" alt="">
                      <p>কল সেন্টার </p>
                    </a>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="/assests/images/tab/agriculture.png" alt="">
                      <p> মৎস্য ও প্রাণী   </p>
                    </a>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="/assests/images/tab/mobile_service.png" alt="">
                    <p> মোবাইল সেবা</p>
                    </a>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="/assests/images/tab/helpdesk.png" alt="">
                      <p>হেল্পডেস্ক</p>
                    </a>
                  </div>
                </div>
              </div>
               <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">...</div>
              <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">...</div>
              <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">...</div>
            </div>
          </div>
          <!-- tab part end here -->
          <div class="list">
          <?php dynamic_sidebar('list'); ?>
           
          </div>
        </div>
        <div class="col-lg-4 hero_main_side d-block">
          <div class="side_img">
            <a href="#">
              <?php dynamic_sidebar('sideimg'); ?>
              <!-- <img src="/assests/images/sidebar/bangladesh-portal--batton-bangla.png" alt=""></a> -->
          </div>
          <div class="side_video">
            <h4>সকল বাতায়ন</h4>
            <form action="">
              <select name="" id="">
                <option value="">ওয়েবসাইট বাছাই করুন</option>
                <option value="">মন্ত্রণালয়</option>
                <option value="">অধিদপ্তর </option>
                <option value="">ঢাকা বিভাগ</option>
                <option value="">চট্টগ্রাম বিভাগ</option>
                <option value="">রাজশাহী বিভাগ</option>
                <option value="">খুলনা বিভাগ</option>
                <option value="">বরিশাল বিভাগ</option>
                <option value="">রংপুর বিভাগ</option>
                <option value="">সিলেট বিভাগ</option>
              </select>
              <button>চলুন</button>
            </form>
            <div class="side_video">
              <!-- <h5>মুজিব১০০ আ্যাপ</h5> -->
              <?php dynamic_sidebar('sidevideo'); ?>
              <!-- <iframe width="315" height="200"src="https://www.youtube.com/embed/4Om3kZJL-qU" title="MUJIB100 APP | Speeches, Quotes, Books & More | Get Inspired Everyday" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
              <!-- <h6>মাস্ক পরুন সেবা নিন</h6>
              <div class="side_img">
                <a href="#"><img src="/assests/images/sidebar/mask-bd-portal (1).jpg" class="d-block w-100" alt=""> </a> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    <!-- hero part end here -->

    <!-- footer part start here -->
    <footer class="cont_p mt-5">
      <?php dynamic_sidebar('footer_top'); ?>
     <div class="row footer_main">
      <img src="/assests/images/footer/download.png" alt="">
     </div>
     <div class="row footer_buttom">
      <div class="col-lg-7 fb_left">
        <ul>
          <li>
            <a href="#">গোপনীয়তার নীতিমালা</a>
          </li>
          <li>
            <a href="#">ব্যবহারের শর্তাবলি</a>
          </li>
          <li>
            <a href="#">সার্বিক সহযোগিতায়</a>
          </li>
          <li>
            <a href="#">সাইট ম্যাপ</a>
          </li>
          <li>
            <a href="#">সচরাচর জিজ্ঞাসা</a>
          </li>
        </ul>
      </div>
      <div class="col-lg-5 fb_right"></div>
     
     </div>
    </footer>
    <!-- footer part end here -->
    <?php wp_footer(); ?>
    <script src="/assests/js/bootstrap.bundle.min.js"></script>
    <section class="cont">
      <?php
      $x = 10;
      while($x<=100){
        ($x % 3 == 0) ? print $x. '<br>' : '';
          $x=$x+5;
      }
      
      ?>
    </section>
  
</body>
</html>